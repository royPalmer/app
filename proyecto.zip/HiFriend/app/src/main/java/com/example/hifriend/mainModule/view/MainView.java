package com.example.hifriend.mainModule.view;

import com.example.hifriend.common.pojo.User;

public interface MainView {
    void friendAdded(User user);
    void friendUpdate(User user);
    void friendRemoved(User user);

    void requestAdded(User user);
    void requestUpdate(User user);
    void requestRemoved(User user);

    void showRequestAccepted(String username);
    void showRequestDenied();

    void showFriendRemoved();

    void showError(int resMsg);
}
