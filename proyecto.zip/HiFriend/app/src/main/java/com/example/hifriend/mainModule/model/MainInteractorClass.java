package com.example.hifriend.mainModule.model;

import com.example.hifriend.common.Constants;
import com.example.hifriend.common.model.BasicEventsCallback;
import com.example.hifriend.common.pojo.User;
import com.example.hifriend.mainModule.events.MaintEvent;
import com.example.hifriend.mainModule.model.dataAccess.Authentication;
import com.example.hifriend.mainModule.model.dataAccess.RealtimeDatabase;
import com.example.hifriend.mainModule.model.dataAccess.UserEventListener;

import org.greenrobot.eventbus.EventBus;

public class MainInteractorClass implements MainInteractor {
    private RealtimeDatabase mDatabase;
    private Authentication mAuthentication;

    private User mMyUser = null;

    public MainInteractorClass(){
        mDatabase = new RealtimeDatabase();
        mAuthentication = new Authentication();
    }

    @Override
    public void subscribeToUserList() {
        mDatabase.subscribeUserList(getCurrentUser().getUid(), new UserEventListener() {
            @Override
            public void onUserAdded(User user) {
                post(MaintEvent.USER_ADDED, user);
            }

            @Override
            public void onUserUpdated(User user) {
                post(MaintEvent.USER_UPDATED, user);
            }

            @Override
            public void onUserRemoved(User user) {
                post(MaintEvent.USER_REMOVED, user);
            }

            @Override
            public void onError(int resMsg) {
                postError(resMsg);
            }
        });

        mDatabase.subscribeToRequest(getCurrentUser().getEmail(), new UserEventListener() {
            @Override
            public void onUserAdded(User user) {
                post(MaintEvent.REQUEST_ADDED, user);
            }

            @Override
            public void onUserUpdated(User user) {
                post(MaintEvent.REQUEST_UPDATED, user);
            }

            @Override
            public void onUserRemoved(User user) {
                post(MaintEvent.REQUEST_REMOVED, user);
            }

            @Override
            public void onError(int resMsg) {
                post(MaintEvent.ERROR_SERVER);
            }
        });

        changeConnectionStatus(Constants.ONLINE);
    }

    private void changeConnectionStatus(boolean online) {
        mDatabase.getmDatabaseAPI().updateMyLastConnection(online, getCurrentUser().getUid());
    }

    @Override
    public void unsubscribeToUserList() {
        mDatabase.unsubscribeToUser(getCurrentUser().getUid());
        mDatabase.unsubscribeToRequest(getCurrentUser().getEmail());

        changeConnectionStatus(Constants.OFFLINE);
    }

    @Override
    public void signOff() {
        mAuthentication.signOff();
    }

    @Override
    public User getCurrentUser() {
        return mMyUser == null? mAuthentication.getmAuthenticationAPI().getAuthUser() : mMyUser;
    }

    @Override
    public void removeFriend(String friendUid) {
        mDatabase.removeUser(friendUid, getCurrentUser().getUid(), new BasicEventsCallback() {
            @Override
            public void onSucces() {
                post(MaintEvent.USER_REMOVED);
            }

            @Override
            public void onError() {
                post(MaintEvent.ERROR_SERVER);
            }
        });
    }

    @Override
    public void acceptRequest(final User user) {
        mDatabase.acceptRequest(user, getCurrentUser(), new BasicEventsCallback() {
            @Override
            public void onSucces() {
                post(MaintEvent.REQUEST_ACCEPTED, user);
            }

            @Override
            public void onError() {
                post(MaintEvent.ERROR_SERVER);
            }
        });
    }

    @Override
    public void denyRequest(final User user) {
        mDatabase.denyRequest(user, getCurrentUser().getEmail(), new BasicEventsCallback() {
            @Override
            public void onSucces() {
                post(MaintEvent.REQUEST_DENIED);
            }

            @Override
            public void onError() {
                post(MaintEvent.ERROR_SERVER);
            }
        });
    }

    private void postError(int resMsg) {
        post(MaintEvent.ERROR_SERVER, null, resMsg);
    }

    private void post(int typeEvent, User user){
        post(typeEvent, user, 0);
    }

    private void post(int typeEvent, User user, int resMsg) {
        MaintEvent event = new MaintEvent();
        event.setTypeEvent(typeEvent);
        event.setUser(user);
        event.setResMsg(resMsg);
        EventBus.getDefault().post(event);
    }

    private void post(int typeEvent) {
        post(typeEvent, null, 0);
    }
}
