package com.example.hifriend.mainModule.model.dataAccess;

import com.example.hifriend.common.pojo.User;

public interface UserEventListener {
    void onUserAdded(User user);
    void onUserUpdated(User user);
    void onUserRemoved(User user);

    void onError(int resMsg);
}
