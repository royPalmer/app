package com.example.hifriend.mainModule;

import com.example.hifriend.common.pojo.User;
import com.example.hifriend.mainModule.events.MaintEvent;

public interface MainPresenter {
    void onCreate();
    void onDestroy();
    void onPause();
    void onResume();

    void signOff();
    User getCurrentUser();
    void removeFriend(String friendUid);

    void acceptRequest(User user);
    void denyRequest(User user);

    void onEventListener(MaintEvent event);
}
