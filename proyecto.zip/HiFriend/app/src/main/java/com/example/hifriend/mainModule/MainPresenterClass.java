package com.example.hifriend.mainModule;

import com.example.hifriend.common.pojo.User;
import com.example.hifriend.mainModule.events.MaintEvent;
import com.example.hifriend.mainModule.model.MainInteractor;
import com.example.hifriend.mainModule.model.MainInteractorClass;
import com.example.hifriend.mainModule.view.MainView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class MainPresenterClass implements MainPresenter {
    private MainView mView;
    private MainInteractor mInteractor;

    public MainPresenterClass(MainView mView){
        this.mView = mView;
        this.mInteractor = new MainInteractorClass();
    }

    @Override
    public void onCreate() {
        EventBus.getDefault().register(this);
    }

    @Override
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        mView = null;
    }

    @Override
    public void onPause() {
        if(mView != null){
            mInteractor.unsubscribeToUserList();
        }
    }

    @Override
    public void onResume() {
        if(mView != null){
            mInteractor.subscribeToUserList();
        }
    }

    @Override
    public void signOff() {
        mInteractor.unsubscribeToUserList();
        mInteractor.signOff();
        onDestroy();
    }

    @Override
    public User getCurrentUser() {
        return mInteractor.getCurrentUser();
    }

    @Override
    public void removeFriend(String friendUid) {
        if(mView != null){
            mInteractor.removeFriend(friendUid);
        }
    }

    @Override
    public void acceptRequest(User user) {
        if(mView != null){
            mInteractor.acceptRequest(user);
        }
    }

    @Override
    public void denyRequest(User user) {
        if(mView != null){
            mInteractor.denyRequest(user);
        }
    }

    @Subscribe
    @Override
    public void onEventListener(MaintEvent event) {
        if(mView != null){
            User user = event.getUser();

            switch(event.getTypeEvent()){
                case MaintEvent.USER_ADDED:
                    mView.friendAdded(user);
                    break;
                case MaintEvent.USER_UPDATED:
                    mView.friendUpdate(user);
                    break;
                case MaintEvent.USER_REMOVED:
                    if (user != null) {
                        mView.friendRemoved(user);
                    } else {
                        mView.showFriendRemoved();
                    }
                    break;
                case MaintEvent.REQUEST_ADDED:
                    mView.requestAdded(user);
                    break;
                case MaintEvent.REQUEST_UPDATED:
                    mView.requestUpdate(user);
                    break;
                case MaintEvent.REQUEST_REMOVED:
                    mView.requestRemoved(user);
                    break;
                case MaintEvent.REQUEST_ACCEPTED:
                    mView.showRequestAccepted(user.getUsername());
                    break;
                case MaintEvent.REQUEST_DENIED:
                    mView.showRequestDenied();
                    break;
                case MaintEvent.ERROR_SERVER:
                    mView.showError(event.getResMsg());
                    break;
            }
        }
    }
}
