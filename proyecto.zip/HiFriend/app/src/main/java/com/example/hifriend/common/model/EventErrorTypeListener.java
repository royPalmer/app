package com.example.hifriend.common.model;

public interface EventErrorTypeListener {
    void onError(int typeEvent, int resMsg);
}
