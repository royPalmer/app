package com.example.hifriend.loginModule.model;

public interface LoginInteractor {
    void onResume();
    void onPause();

    void getStatusAuth();
}
