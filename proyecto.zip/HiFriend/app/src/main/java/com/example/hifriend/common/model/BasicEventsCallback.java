package com.example.hifriend.common.model;

public interface BasicEventsCallback {
    void onSucces();
    void onError();
}
