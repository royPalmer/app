package com.example.hifriend.mainModule.view.adapters;

import com.example.hifriend.common.pojo.User;

public interface OnItemClickListener {
    void onItemClick(User user);
    void onItemLongClick(User user);

    void onAcceptRequest(User user);
    void onDenyRequest(User user);
}
