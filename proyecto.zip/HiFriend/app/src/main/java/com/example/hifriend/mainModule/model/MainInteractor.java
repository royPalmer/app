package com.example.hifriend.mainModule.model;

import com.example.hifriend.common.pojo.User;

public interface MainInteractor {
    void subscribeToUserList();
    void unsubscribeToUserList();

    void signOff();

    User getCurrentUser();
    void removeFriend(String friendUid);

    void acceptRequest(User user);
    void denyRequest(User user);
}
